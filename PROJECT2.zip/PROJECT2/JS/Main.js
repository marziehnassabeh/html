alert("TEst");


function Hello() {

    var user = prompt("what is your name");
    document.getElementById('here1').innerHTML =
        " Hello " + user + " welcome to my website";

}

function Hello2() {

    var user = prompt("what is your name");
    document.getElementById('here2').innerHTML =
        " Hello " + user + " welcome to my website";

}

function Sum() {

    var numb1 = parseInt(document.getElementById("number1").value);
    var number2 = parseInt(document.getElementById("number2").value);
    var total = numb1 + number2;

    document.getElementById("total").innerHTML = total;
}

function average() {

    var grade1 = parseInt(document.getElementById("grade1").value);
    var grade2 = parseInt(document.getElementById("grade2").value);
    var grade3 = parseInt(document.getElementById("grade3").value);
    var result = (grade1 + grade2 + grade3) / 3;

    if (result < 6) {
        document.getElementById("statue").innerHTML = "You Failed";
    } else {
        document.getElementById("statue").innerHTML = "You Passed";

    }

    document.getElementById("result").innerHTML = "Your average is" + result;

}

function subtract() {

    var numb1 = parseInt(document.getElementById("numb1").value);
    var numb2 = parseInt(document.getElementById("numb2").value);
    var total = numb1 - numb2;

    document.getElementById("answer").innerHTML = answer;
}





function multiply() {

    var nub1 = parseInt(document.getElementById("nub1").value);
    var nub2 = parseInt(document.getElementById("nub2").value);
    var total = num1 * num2;

    document.getElementById("totall").innerHTML = totall;
}


function Rain() {
    var Rain = prompt(" IS it raining? Yes:1, No:0");
    if (rain == 0) {
        console.log("Dont take your Amberella ")
    } else {
        "Take your Amberella "
    }

}